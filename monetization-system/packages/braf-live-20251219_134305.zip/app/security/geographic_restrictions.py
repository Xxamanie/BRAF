"""
Geographic Restrictions
BLOCK high-risk jurisdictions
"""

HIGH_RISK_JURISDICTIONS = [
    "Iran", "North Korea", "Syria", "Crimea",
    "Cuba", "Donetsk", "Luhansk"
]

SANCTIONED_COUNTRIES = [
    "Russia", "Belarus", "Myanmar", "Venezuela"
]